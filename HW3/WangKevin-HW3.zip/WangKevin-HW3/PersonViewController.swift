//
//  PersonViewController.swift
//  WangKevin-HW3
//
//  Created by Wang, Kevin on 9/26/17.
//  Copyright © 2017 Wang, Kevin. All rights reserved.
//

import UIKit

class PersonViewController: UIViewController {
    var person: Person?
    @IBOutlet weak var FName: UILabel!
    @IBOutlet weak var LName: UILabel!
    @IBOutlet weak var Age: UILabel!
    @IBOutlet weak var City: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let barButton = UIBarButtonItem()
        barButton.title = "Person List"
        self.title = "Person"
        self.navigationItem.title = "Person"
        FName.text = person?.FirstName
        LName.text = person?.LastName
        Age.text = person?.Age?.description
        City.text = person?.City
        
        navigationController!.navigationBar.topItem!.backBarButtonItem = barButton
        // Do any additional setup after loading the view.
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
