//
//  Person.swift
//  WangKevin-HW3
//
//  Created by Wang, Kevin on 9/26/17.
//  Copyright © 2017 Wang, Kevin. All rights reserved.
//

import Foundation

class Person{
    var FirstName:String?
    var LastName:String?
    var Age:Int32?
    var City:String?
    init(FirstName:String?, LastName:String?, Age:Int32?, City:String?) {
        self.FirstName = FirstName
        self.LastName = LastName
        self.Age = Age
        self.City = City
    }
}
