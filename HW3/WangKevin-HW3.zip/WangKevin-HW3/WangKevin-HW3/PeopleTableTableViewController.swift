//
//  PeopleTableTableViewController.swift
//  WangKevin-HW3
//
//  Created by Wang, Kevin on 9/26/17.
//  Copyright © 2017 Wang, Kevin. All rights reserved.
//

import UIKit

class PeopleTableTableViewController: UITableViewController {
    
    var peopleList: [Person]?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Person List"
        self.navigationItem.title = "Person List"
        self.createDataModel()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    func createDataModel(){
        //data model
        self.peopleList = [Person(FirstName: "Bob",LastName:"Carpenter",Age:35,City:"Austin"),Person(FirstName:"John",LastName:"Jones",Age:8,City:"Boston"),Person(FirstName:"Led",LastName:"Zeppelin",Age:73, City: "Paris"),Person(FirstName:"Sam",LastName:"Smith",Age:34,City:"Sydney"),Person(FirstName:"June",LastName:"Johnson",Age:12,City:"Vienna"),Person(FirstName:"Allison",LastName:"Atwater",Age:21,City:"Venice"),Person(FirstName:"Donald",LastName:"Trump",Age:56,City:"Munich"),Person(FirstName:"Hillary",LastName:"Clinton",Age:69,City:"Brussels"),Person(FirstName:"Barrack",LastName:"Obama",Age:53,City:"Tokyo"),Person(FirstName:"Teddy", LastName:"Roosevelt",Age:70,City:"Shanghai")]
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return (self.peopleList?.count)!
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)

        // Configure the cell...
        let rowNumber = indexPath.row
        let person = peopleList?[rowNumber]
        cell.textLabel?.text = person?.FirstName
        cell.detailTextLabel?.text = person?.LastName
        
        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "ShowDetail"{
            if let dsvc = segue.destination as? PersonViewController{
                let selectedindex = tableView.indexPathForSelectedRow
                dsvc.person = peopleList?[(selectedindex?.row)!]
            }
            
        }
    }
 

}
