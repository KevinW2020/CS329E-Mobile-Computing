Implementation Contributions: 
  Amar: 33%
  - Backend Disease database Setup with Firebase
  Kevin: 33%
  - Search functionality
  Khalil: 33%
  - Firebase setup and Login pages

Grading Level:
Kevin and Khalil 100%. Amar 70%.

Differences: We were unable to use Firebase Database for the diseases and doctors so we stored them internally. Both search functions are working. We scrapped the review feature and just made our app basic with simple search functionality that is clean and easy to use.  

Special Instructions: We used CocoaPods Version 1.3.1. To log in, use the username: a@gmail.com and password: abc123


  
	