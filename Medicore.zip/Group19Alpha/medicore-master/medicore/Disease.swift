//
//  Disease.swift
//  medicore
//
//  Created by Khalil Manpuri on 11/21/17.
//  Copyright © 2017 Final Project. All rights reserved.
//

import Foundation
class Disease{
    var Name:String?
    var signal = [String]()
    var Desc:String?
    var Cure:String?
    init(Name: String){
        self.Name = Name
  }
}
